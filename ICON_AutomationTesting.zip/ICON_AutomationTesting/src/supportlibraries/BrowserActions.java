package supportlibraries;

import java.awt.Desktop;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

//import ExcelDataFiles.ExcelUtilities;
import bussiesscomponents.Orange;


public class BrowserActions {

	public static WebDriver driver;
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- Browser Actions
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	public static void launchBrowser() throws Exception {
		 
		try {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--incognito");
			System.setProperty("webdriver.chrome.driver", "ChromeDriver\\chromedriver.exe");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			//ExcelUtilities	xl = new ExcelUtilities("TestData\\LoginData.xlsx");
			driver.get("https://orangehrm-demo-6x.orangehrmlive.com/auth/login");
			driver.manage().deleteAllCookies();
			//test.pass(xl.getCellData("URL", 2, 0));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			////test.fail("Failed to Brower Lanch");
			e.printStackTrace();
		}
	}
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- Extent report generating
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	@BeforeSuite
	public static void setUp() throws Exception {
	}
	
		
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- End of the script open the report
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	
	@AfterSuite
	public static void tearDown() throws Exception {
		
	}

	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- PSMS Application Modules
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * @Framework --- TestNg and Data Driven Framework(Hybrid Framework)
	 * 
	 * ##############################################################
	 */
	public static void modulesPage() throws Throwable {

		ExcelUtilities xla = new ExcelUtilities("TestData\\TestScenarios1.xlsx");
		int row = xla.getRowCount("Modules")+1;
		int col = xla.getColumnCount("Modules");

		// Excel sheet data count
		System.out.println("no.of rows :" + row + " " + "no.of columns :" + col);

		// Iterator for loop
		for (int Modules = 2; Modules <= row; Modules++) {

			String ModuleName = xla.getCellData("Modules", Modules, 0);
			String IsExcute = xla.getCellData("Modules", Modules, 1);

			if (IsExcute.contentEquals("Y") && ModuleName.contentEquals("Orange")) {
				// --Register page--
				Orange.Navigate();
			}

		}
	}
}
