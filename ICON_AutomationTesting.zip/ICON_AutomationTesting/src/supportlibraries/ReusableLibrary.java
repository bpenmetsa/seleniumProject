package supportlibraries;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import uimap.SamplePaths;

public class ReusableLibrary {
	
	
	public static void ClickBtn(By locator) {
		
		BrowserActions.driver.findElement(locator).click();
	}
	

}
