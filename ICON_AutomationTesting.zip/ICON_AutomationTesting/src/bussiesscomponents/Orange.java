package bussiesscomponents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import TestScripts.NewTest;
import supportlibraries.BrowserActions;
import supportlibraries.ReusableLibrary;
import uimap.SamplePaths;

public class Orange {
	static WebDriver Element = BrowserActions.driver;
	


	public static void Navigate() {
		
		//driver.findElement(SamplePaths.btnlogin).click();
		System.out.println("executing navigate method");
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).sendKeys("admin");
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).sendKeys("admin123");
		Element.findElement(By.xpath("//input[@name=\"Submit\"]")).click();
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).sendKeys("admin");
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).sendKeys("admin123");
		//Element.findElement(By.xpath("//button[@name='Submit']")).click();
		ReusableLibrary.ClickBtn(SamplePaths.btnlogin);
		Element.findElement(By.xpath("//*[@id=\"menu_admin_viewAdminModule\"]/a/span[3]")).click();
	}
	


	
}
