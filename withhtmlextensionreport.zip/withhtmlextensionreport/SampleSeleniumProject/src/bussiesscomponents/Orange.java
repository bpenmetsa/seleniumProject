package bussiesscomponents;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import TestScripts.NewTest;
import supportlibraries.BrowserActions;
import supportlibraries.ExcelUtilities;
import supportlibraries.ReusableLibrary;
import uimap.SamplePaths;

public class Orange {
	static WebDriver Element = BrowserActions.driver;
	
	
	private static ExcelUtilities xl=new ExcelUtilities("TestData\\TestScenarios.xlsx");

	static String UserName = xl.getCellData("LoginDeatils", 2, 1);
	static String Password = xl.getCellData("LoginDeatils", 2, 2);
	
	public static void Navigate() throws IOException {
		
		//driver.findElement(SamplePaths.btnlogin).click();
		//BrowserActions.extent.createTest("OrangeLogin Test");
		//BrowserActions.extent.createTest("OrangeLogin Test");
		try {
		System.out.println("executing navigate method");
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).sendKeys(UserName);
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).sendKeys(Password);
		Element.findElement(By.xpath("//input[@name=\"Submit\"]")).click();
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).sendKeys(UserName);
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).sendKeys(Password);
		//Element.findElement(By.xpath("//button[@name='Submit']")).click();
		ReusableLibrary.ClickBtn(SamplePaths.btnlogin);
		BrowserActions.test.log(Status.PASS, "Orange login");
		Element.findElement(By.xpath("//*[@id=\"menu_admin_viewAdminModule\"]/a/span[3]")).click();
		
		Element.findElement(By.xpath("//*[@id=\"account-job\"]/i")).click();
		Element.findElement(By.xpath("//*[@id=\"logoutLink\"]")).click();
	
		
	
		BrowserActions.test.log(Status.PASS, "Orange Test PASS");
		//BrowserActions.test.pass("Orange Test PASS");
		}  catch (Exception e) {
			System.out.println("Object not found := "+e.getMessage());
			BrowserActions.test.fail("Orange Test Fail", MediaEntityBuilder.createScreenCaptureFromBase64String(ReusableLibrary.getScreenshot()).build());
			//Element.quit();
			//Assert.assertTrue(false);
			e.printStackTrace();
		}
	
}
}
