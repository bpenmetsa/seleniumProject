package bussiesscomponents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import supportlibraries.BrowserActions;
import supportlibraries.ExcelUtilities;
import supportlibraries.ReusableLibrary;
import uimap.SamplePaths;

public class DummyClass {
	static WebDriver Element = BrowserActions.driver;
	private static ExcelUtilities xl=new ExcelUtilities("TestData\\TestScenarios.xlsx");

	static String UserName = xl.getCellData("LoginDeatils", 2, 3);
	static String Password = xl.getCellData("LoginDeatils", 2, 4);
	
	public static void Navigate1() {
		
		//driver.findElement(SamplePaths.btnlogin).click();
		
		System.out.println("executing Dummy class navigate method");
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtUsername\"]")).sendKeys(UserName);
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).clear();
		Element.findElement(By.xpath("//input[@id=\"txtPassword\"]")).sendKeys(Password);
		Element.findElement(By.xpath("//input[@name='Submit']")).click();
		//ReusableLibrary.ClickBtn(SamplePaths.btnlogin);
		Element.findElement(By.xpath("//*[@id=\"menu_admin_viewAdminModule\"]/a/span[3]")).click();
		Element.findElement(By.xpath("//*[@id=\"account-job\"]/i")).click();
		Element.findElement(By.xpath("//*[@id=\"logoutLink\"]")).click();
		BrowserActions.test.log(Status.PASS, "Dummy login");
	}
	

}
