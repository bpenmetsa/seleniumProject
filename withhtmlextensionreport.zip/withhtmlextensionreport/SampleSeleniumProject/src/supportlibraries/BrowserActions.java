package supportlibraries;

import java.awt.Desktop;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import bussiesscomponents.DummyClass;
//import ExcelDataFiles.ExcelUtilities;
import bussiesscomponents.Orange;


public class BrowserActions {

	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest test;
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- Browser Actions
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	public static void launchBrowser() throws Exception {
		 test = extent.createTest("Brower Lanch");
		 
		try {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--incognito");
			System.setProperty("webdriver.chrome.driver", "D:\\seleniumjar\\chromdriver\\chromedriver.exe");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			//ExcelUtilities	xl = new ExcelUtilities("TestData\\LoginData.xlsx");
			driver.get("https://orangehrm-demo-6x.orangehrmlive.com/auth/login");
			driver.manage().deleteAllCookies();
			//test.pass(xl.getCellData("URL", 2, 0));
			test.pass("BrowerLaunched Sucessfully");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			test.fail("Failed to Brower Lanch");
			e.printStackTrace();
		}
	}
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- Extent report generating
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	@BeforeSuite
	public static void setUp() throws Exception {
		extent = new ExtentReports();
		ExtentSparkReporter spark = new ExtentSparkReporter("index.html");// html file to be generate
		final File CONF = new File("ExtentConfig.xml");
		spark.loadXMLConfig(CONF);
		extent.attachReporter(spark);
	}
	
		
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- End of the script open the report
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	public static void driverQuit() {
		
		driver.quit();
		
	}
	@AfterSuite
	public static void tearDown() throws Exception {
		extent.flush();
		Desktop.getDesktop().browse(new File("index.html").toURI());
		
	}

	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- PSMS Application Modules
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * @Framework --- TestNg and Data Driven Framework(Hybrid Framework)
	 * 
	 * ##############################################################
	 */
	public static void modulesPage() throws Throwable {

		ExcelUtilities xla = new ExcelUtilities("TestData\\TestScenarios.xlsx");
		int row = xla.getRowCount("Modules")+1;
		int col = xla.getColumnCount("Modules");

		// Excel sheet data count
		System.out.println("no.of rows :" + row + " " + "no.of columns :" + col);

		// Iterator for loop
		for (int Modules = 2; Modules <= row; Modules++) {

			String ModuleName = xla.getCellData("Modules", Modules, 0);
			String IsExcute = xla.getCellData("Modules", Modules, 1);

			if (IsExcute.contentEquals("Y") && ModuleName.contentEquals("Orange")) {
				// --Register page--
				test = extent.createTest("Orange test");
				Orange.Navigate();
			}
			if (IsExcute.contentEquals("Y") && ModuleName.contentEquals("DummyClass")) {
				// --Register page--
				test = extent.createTest("Dummy test");
				DummyClass.Navigate1();
			}

		}
	}
}
