package supportlibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


import uimap.SamplePaths;

public class ReusableLibrary {
	
	
	public static void ClickBtn(By locator) {
		
		BrowserActions.driver.findElement(locator).click();
	}
	public static String getScreenshot() throws IOException {
	    File source = ((TakesScreenshot)BrowserActions.driver).getScreenshotAs(OutputType.FILE);
	    String path = System.getProperty("user.dir")+"/Screenshots/image.png";
	    FileUtils.copyFile(source,new File(path));
	
	    byte[] imagebytes = IOUtils.toByteArray(new FileInputStream(path));
	    return Base64.getEncoder().encodeToString(imagebytes);
	}

}
