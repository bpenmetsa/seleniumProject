package uimap;

import org.openqa.selenium.By;

public class SamplePaths {

	public static final By btnlogin = By.xpath("//*[@id=\"btnLogin\"]");
	
	
}
