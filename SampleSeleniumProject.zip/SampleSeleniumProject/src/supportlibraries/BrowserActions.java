package supportlibraries;

import java.awt.Desktop;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class BrowserActions {

	public static WebDriver driver;
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- Browser Actions
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	public static void launchBrowser() throws Exception {
		 
		try {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--incognito");
			System.setProperty("webdriver.chrome.driver", "D:\\seleniumjar\\chromdriver\\chromedriver.exe");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			//ExcelUtilities	xl = new ExcelUtilities("InputFiles\\LoginData.xlsx");
			driver.get("https://orangehrm-demo-6x.orangehrmlive.com/auth/login");
			//driver.manage().deleteAllCookies();
			////test.pass(xl.getCellData("URL", 2, 0));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			////test.fail("Failed to Brower Lanch");
			e.printStackTrace();
		}
	}
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- Extent report generating
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	@BeforeSuite
	public static void setUp() throws Exception {
	}
	
		
	
	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- End of the script open the report
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * ##############################################################
	 */
	
	@AfterSuite
	public static void tearDown() throws Exception {
		
	}

	/*
	 * ##############################################################
	 * 
	 * @Descriptions --- PSMS Application Modules
	 * 
	 * @param driver --- WebDriver parameter
	 * 
	 * @Framework --- TestNg and Data Driven Framework(Hybrid Framework)
	 * 
	 * ##############################################################
	 */
	
}
