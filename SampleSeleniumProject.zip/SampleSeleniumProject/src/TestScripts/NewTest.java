package TestScripts;

import org.testng.annotations.Test;


import bussiesscomponents.Orange;
import supportlibraries.BrowserActions;

import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class NewTest extends BrowserActions{
	
	
  @Test
  public void OrngeHrmsLogin() {
	  Orange.Navigate();
	  
	  
  }
  @BeforeMethod
  public void beforeMethod() throws Exception {
	  
	  launchBrowser();
	 	  
  }

  @AfterMethod
  public void afterMethod() {
	 
  }
  

}
