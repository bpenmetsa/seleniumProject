package bussiesscomponents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import TestScripts.NewTest;
import supportlibraries.BrowserActions;
import supportlibraries.ReusableLibrary;
import uimap.SamplePaths;

public class Orange {
	static WebDriver Element = BrowserActions.driver;
	


	public static void Navigate() {
		
		//driver.findElement(SamplePaths.btnlogin).click();
		ReusableLibrary.ClickBtn(SamplePaths.btnlogin);
		Element.findElement(By.xpath("//*[@id=\"menu_admin_viewAdminModule\"]/a/span[3]")).click();
	}
	


	
}
